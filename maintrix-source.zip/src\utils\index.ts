/**
 * Frontend utilities - placeholder.
 */
export {};
