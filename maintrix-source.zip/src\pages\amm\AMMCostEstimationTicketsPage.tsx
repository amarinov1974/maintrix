/**
 * AMM Tickets Awaiting Cost Estimation — list (newest first) with preview.
 */

import { useState } from 'react';
import { Link } from 'react-router-dom';
import { useQuery } from '@tanstack/react-query';
import { ticketsAPI } from '../../api/tickets';
import { useSession } from '../../contexts/SessionContext';
import { Layout, Button, Badge } from '../../components/shared';
import { AMMTicketDetailModal } from './AMMTicketDetailModal';
import { TicketStatus } from '../../types/statuses';
import type { Ticket } from '../../api/tickets';

const DESCRIPTION_PREVIEW_LENGTH = 120;

function descriptionPreview(description: string): string {
  const trimmed = description.trim();
  if (trimmed.length <= DESCRIPTION_PREVIEW_LENGTH) return trimmed;
  return trimmed.slice(0, DESCRIPTION_PREVIEW_LENGTH).trim() + '…';
}

function getStatusBadgeVariant(status: string): 'default' | 'success' | 'warning' | 'danger' {
  if (status.includes('Approved')) return 'success';
  if (status.includes('Rejected') || status.includes('Withdrawn')) return 'danger';
  return 'warning';
}

export function AMMCostEstimationTicketsPage() {
  const { session } = useSession();
  const [selectedTicketId, setSelectedTicketId] = useState<number | null>(null);

  const { data: ownedTickets = [], isLoading } = useQuery({
    queryKey: ['tickets', 'amm-owned', session?.userId],
    queryFn: () => ticketsAPI.list({ currentOwnerUserId: session!.userId }),
    enabled: session?.userId != null,
  });

  // Only non-urgent: urgent tickets in Cost Estimation Needed appear under Urgent Tickets
  const costEstimationTickets = ownedTickets
    .filter(
      (t) =>
        t.currentStatus === TicketStatus.COST_ESTIMATION_NEEDED && !t.urgent
    )
    .sort((a, b) => new Date(b.createdAt).getTime() - new Date(a.createdAt).getTime());

  return (
    <Layout screenTitle="Tickets Awaiting Cost Estimation">
      <div className="max-w-4xl mx-auto space-y-4">
        <div className="flex flex-wrap items-center justify-between gap-4">
          <div>
            <h1 className="text-2xl font-bold text-gray-900">Tickets Awaiting Cost Estimation</h1>
            <p className="text-sm text-gray-600 mt-0.5">
              Non-urgent tickets in Cost Estimation Needed, owned by you — newest first
            </p>
          </div>
          <Link to="/amm">
            <Button type="button" variant="secondary">
              Back to dashboard
            </Button>
          </Link>
        </div>

        {isLoading ? (
          <p className="text-gray-500">Loading…</p>
        ) : costEstimationTickets.length === 0 ? (
          <div className="rounded-lg border border-gray-200 bg-gray-50 p-6 text-center text-gray-600">
            No tickets awaiting cost estimation.
          </div>
        ) : (
          <ul className="space-y-2">
            {costEstimationTickets.map((ticket) => (
              <li key={ticket.id}>
                <TicketPreviewRow
                  ticket={ticket}
                  onOpen={() => setSelectedTicketId(ticket.id)}
                />
              </li>
            ))}
          </ul>
        )}
      </div>

      {selectedTicketId != null && (
        <AMMTicketDetailModal
          ticketId={selectedTicketId}
          onClose={() => setSelectedTicketId(null)}
        />
      )}
    </Layout>
  );
}

function TicketPreviewRow({ ticket, onOpen }: { ticket: Ticket; onOpen: () => void }) {
  return (
    <button
      type="button"
      className="w-full text-left p-4 rounded-lg border border-gray-200 hover:bg-blue-50/50 hover:border-blue-200 cursor-pointer transition focus:outline-none focus:ring-2 focus:ring-blue-500 focus:ring-offset-1"
      onClick={(e) => {
        e.preventDefault();
        e.stopPropagation();
        onOpen();
      }}
    >
      <div className="flex flex-wrap items-center gap-2 mb-2">
        <span className="font-semibold text-gray-900">Ticket #{ticket.id}</span>
        {ticket.urgent && <Badge variant="urgent">URGENT</Badge>}
        <Badge variant={getStatusBadgeVariant(ticket.currentStatus)}>{ticket.currentStatus}</Badge>
        <span className="text-sm text-gray-600">{ticket.storeName}</span>
        <span className="text-sm text-gray-500">
          {new Date(ticket.createdAt).toLocaleDateString()}
        </span>
      </div>
      <p className="text-sm text-gray-700 whitespace-pre-wrap line-clamp-2">
        {descriptionPreview(ticket.originalDescription ?? ticket.description)}
      </p>
    </button>
  );
}
